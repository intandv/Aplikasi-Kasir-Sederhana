import java.awt.*;
import java.awt.print.*;

public class StrukPrinter {

    public void printStruk(int nomorMeja, String[][] dataPesanan, int totalBayar, int uangDiterima) {
        PrinterJob printerJob = PrinterJob.getPrinterJob();
        printerJob.setPrintable(new Printable() {
            @Override
            public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
                if (pageIndex > 0) {
                    return Printable.NO_SUCH_PAGE; // Jika lebih dari satu halaman, abaikan
                }

                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

                // Mulai menggambar struk
                int y = 20; // Posisi awal Y
                g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));

                // Header Struk
                g2d.drawString("----- Rajo Seblak -----", 10, y);
                y += 20;
                g2d.drawString("Nomor Meja: " + nomorMeja, 10, y);
                y += 20;
                g2d.drawString("-----------------------", 10, y);
                y += 20;

                // Isi Pesanan
                g2d.drawString("Menu          Qty  Harga   Total", 10, y);
                y += 20;
                for (String[] pesanan : dataPesanan) {
                    String menu = pesanan[0];
                    String qty = pesanan[1];
                    String harga = pesanan[2];
                    String total = pesanan[3];

                    g2d.drawString(String.format("%-12s %3s %6s %7s", menu, qty, harga, total), 10, y);
                    y += 20;
                }

                // Footer Struk
                g2d.drawString("-----------------------", 10, y);
                y += 20;
                g2d.drawString("Total Bayar : Rp " + totalBayar, 10, y);
                y += 20;
                int kembalian = uangDiterima - totalBayar;
                g2d.drawString("Uang Diterima: Rp " + uangDiterima, 10, y);
                y += 20;
                g2d.drawString("Kembalian    : Rp " + kembalian, 10, y);
                y += 20;
                g2d.drawString("----- Terima Kasih -----", 10, y);

                return Printable.PAGE_EXISTS;
            }
        });

        // Tampilkan dialog print
        boolean doPrint = printerJob.printDialog();
        if (doPrint) {
            try {
                printerJob.print();
            } catch (PrinterException e) {
                System.err.println("Gagal mencetak: " + e.getMessage());
            }
        }
    }
}
